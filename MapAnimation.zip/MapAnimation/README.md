
# Map Animation

街の画像のガイドアニメーションサンプル

## ファイル構成
```
kenpatsu_demo
  ├ css
  | ├ four_in_one.css
  | ├ four_in_one.sass
  | ├ map.css
  | ├ map.sass
  | └ style.css
  ├ img
  ├ js
  | ├ jquery-3.3.1.min.js
  | ├ jquery.backgroundPosition.js
  | └ map.js
  ├ semantic-UI
  ├ video
  ├ four_in_one.html
  └ map.html
```

* `css/*`：スタイルシート
* `img/*`：画像
* `js/*`：JSファイル
* `js/dashboard.js`：俯瞰図画面アニメーションJS
* `semantic-UI/*`：Semantic-UIコアファイル
* `video/*`：動画
* `four_in_one.html`：ダッシュボード画面
* `map.html`：俯瞰図画面


## 開発 / 実行環境
* 言語：HTML5, JS(JQuery Ver.3.3.1), CSS(SASS)
* ツール/ライブラリ：Koala(Ver.2.3.0), Semantic-UI
* 環境：Windows10, GoogleChrome

#### [Koala](http://koala-app.com/)
SASSファイルをCSSにコンパイルするために使用。
CSSを直接編集する場合は不要。

#### [Semantic-UI](https://semantic-ui.com/)
`map.html`のマーカーアイコンのイラスト、`four_in_one.html`の４分割のグリッドなど、細かいUIを簡単に実現する際に使用。
（[インストール方法](https://semantic-ui.com/introduction/getting-started.html#using-build-tools)）


## 仕様
直接実行する主なファイルは以下の2ファイルです。
* map.html：支援ソリューション紹介画面
* four_in_one.html：ダッシュボード画面

### map.html
ここで定義した、国分寺市俯瞰図の背景と複数のマーカーに
`js/map.js`で動的要素を付加し、一定時間でループさせることによってアニメーションを表現。

#### js/map.js

###### ■ Variables
* arr：背景画像の拡大表示させる背景の座標を定義
* markers：背景画像の拡大表示時のマーカー表示場所を定義
* ini_marekers：初期表示時のマーカー表示場所を定義

###### ■ Fn
* `initiate_pos()`： マーカーを初期表示
* `anims()`： ループさせる基本アニメ
* `_anim1(key, delay)`： 基本アニメ実行時の背景画像位置の移動
* `_anim2(keys, delay)`： 基本アニメ実行時のマーカーの表示/非表示
* `zoomout()`： 背景画像の縮小表示
* `zoomin()`： 背景画像の拡大表示
<br>

###### 1. 初期画面表示時アニメーション
###### [仕様]
以下の一連のアニメーション
* 俯瞰図全体が画面に収まるように表示される
* その上に各支援のマーカーアイコンが表示される
* タイトルがフェードイン
* 5秒後にタイトルがフェードアウト

###### [処理]
* タイトルをフェードイン・アウト（1s待 -> 1sFadeIn -> 5s待 -> 1sFadeOut）
* 背景画像の初期ポジション設定（画像中央）
* `initiate_pos()`関数実行：
  * オブジェクト変数`ini_markers`の各要素について、表示位置情報`top`,`left`をcssのプロパティとして値をセット
  * マーカーを拡大表示させるクラス:`massive`を除去


###### 2. ループアニメーション
###### [仕様]
以下の一連のアニメーションをループ再生する
* 背景画像の中央を中心とし、背景がズームイン
* public, officeのマーカーに関連する絵の付近に背景の中心を移動
* public, officeマーカーがフェードイン
* 4秒後にマーカーフェードアウト
* industry, terminalのマーカーに関連する絵の付近に背景の中心を移動
* industry, terminalマーカーがフェードイン
* 4秒後にマーカーフェードアウト
* 俯瞰図全体が画面に収まるように表示される
* その上に各支援のマーカーアイコンが表示される
* タイトルがフェードイン
* 5秒後にタイトルがフェードアウト
* ズームイン

###### [処理]
* 基本的に33秒ごとに`anims()`をループ実行する
* ループの初回でも、33秒待ってしまうため、最初は待ち時間なしでanims()を実行
* 上記とは別のタイムラインで、6秒遅延時間を発生させ、`zoomin()`関数を実行させて仕様の最初の項目のアクションを実現

```
※ 各関数の内容etc. 処理詳細はコードコメントを参照してください。
```

#### js/jquery.backgroundPosition.js
backgroundPosition（背景位置の調整）プロパティは、
jQueryの.animate()関数で実行できないため、
これを補うために使用。

-> [backgroundPosition.js](http://css-tricks.com/examples/StarryNightMoving.zip)



### four_in_one.html
###### [仕様]
4分割した画面上に、各ユニットの紹介動画をループ再生させる

###### [処理]
動画を埋め込む`<video>`タグに、`autoplay`, `loop`, `muted`の属性を付与して、動画のループ再生と自動再生をさせている

```
※ 処理詳細はコードコメントを参照してください。
```


## 実行方法
各HTMLファイルをブラウザで実行
