/************************
 * Map.html Animation JS
 ************************/

/** Frame Targets
 *  Single-Place / MultiPlace Mode
 *  (eg.'kyoso') / (eg.'kyoso-office') */
var arr = {
  "kyoso-office": { "x":'60%', "y":'0%' },
  "industry-terminal": { "x":'100%', "y":'100%' },
};

/* Marker Positions */
var markers = {
  "kyoso": { "left":'30%', "top":'37%' },
  "office": { "left":'73%', "top":'10%' },
  "industry": { "left":'64%', "top":'70%' },
  "terminal": { "left":'75%', "top":'15%' }
};

/* Initial Marker Positions */
var ini_markers = {
  "kyoso": { "left":'45%', "top":'37%' },
  "office": { "left":'70%', "top":'21%' },
  "industry": { "left":'85%', "top":'50%' },
  "terminal": { "left":'5%', "top":'50%' }
};

$(function() {
  /* INITIAL ANIMATION */
  $('#title').hide().delay(1000).fadeIn(1000).delay(5000).fadeOut(1000);
  $('#place_img_area').css({backgroundPosition: '50% 50%'});
  initiate_pos();

  /* LOOP ANIMATION */
  anims();
  setTimeout(function() {
    zoomin();
  }, 6000);
  setInterval(function() {
    anims();
  }, 33000);
});

// Initiate Marker Positions & Sizes
function initiate_pos() {
  $.each(ini_markers, function(key, val) {
    $("#" + key).css({
      top: val["top"],
      left: val["left"]
    });
    $("#" + key + " > span").removeClass('massive');
  });
}

// Do Anime
function anims() {
  var i = 1;
  var timer = setInterval(function() {
    var key = Object.keys(arr)[i-1];
    // Break & Initiate Positions after the end-point of 'arr'
    if (key === undefined) {
      initiate_pos();
      zoomout();
      clearInterval(timer);
    }
    // Animations
    $.when(
      _anim1(key, 1000)
    ).then(function() {
      _anim2(key, 100);
    });
    i++;
  }, 10000);
}

// Move Background Position
function _anim1(key, delay) {
  var d = $.Deferred();
  $('#place_img_area')
  .delay(delay)
  .animate({
      backgroundPositionX:arr[key]['x'],
      backgroundPositionY:arr[key]['y'],
  }, 4000, 'linear', function() {
    d.resolve();
  });
  return d.promise();
}

// Show & Replace Markers
function _anim2(keys, delay) {
  var d = $.Deferred();
  var keys = keys.split('-');
  // when key of 'arr' is :
  if (keys.length > 1) {
    // Multi-Place Mode
    var target = "";
    $.each(keys, function(i, v) {
      $("#" + v).css({
        top: markers[v]["top"],
        left: markers[v]["left"]
      });
      $("#" + v + " > span").addClass('massive');
      if (i > 0) { target += ", "; }
      target += "#" + v;
    });
  } else {
    // Single-Place Mode
    $("#" + keys).css({
      top: markers[keys]["top"],
      left: markers[keys]["left"]
    });
    $("#" + keys + " > span").addClass('massive');
    var target = "#" + keys;
  }
  // Fade In-Out Markers
  $(target)
  .delay(delay)
  .fadeIn(500)
  .delay(4000)
  .fadeOut(500, function() {
    d.resolve();
  });
  return d.promise();
}

// Zoom Out Anime
function zoomout() {
  $('.place_btn').fadeIn(4000);
  $('#place_img_area')
  .animate({
      backgroundPositionX: "50%",
      backgroundPositionY: "50%",
      backgroundSize: "100%",
  }, 4000, 'linear', function() {
    $('#title').fadeIn(2000, function() {
      setTimeout(function() { zoomin(); }, 1000);
    });
  });
}

// Zoom In Anime
function zoomin() {
  $('.place_btn').hide();
  $('#place_img_area')
  .animate({
      backgroundPositionX: "50%",
      backgroundPositionY: "50&",
      backgroundSize: "220%",
  }, 4000, 'linear', function() {
    $('#title').fadeOut(1000);
  });
}
